<?php require_once __DIR__ . '/../../app/bootstrap.php'; crud_delete('services', (string)($_GET['id'] ?? ''));
